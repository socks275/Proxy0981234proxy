# Nova Educational Gateway

A small educational web gateway with a cyber-style frontend and a Cloudflare Worker backend.

## Safety design

The backend is deliberately **allowlist-only**. It is not an unrestricted open proxy.

Edit `worker.js`:

```js
const ALLOWED_HOSTS = new Set([
  "example.com",
  "www.example.com"
]);
```

Add only domains you own, operate, or have explicit permission to access through the gateway.

## Deploy to Cloudflare Workers

1. Create a Cloudflare Worker.
2. Put the contents of `worker.js` into the Worker editor.
3. Deploy it.
4. Serve `index.html` and `sw.js` from the same origin using your preferred static hosting setup, or adapt the Worker to serve the files.
5. Keep the Worker and frontend on the same origin so `/api/proxy` works.

## Local testing

Because browser Service Workers and fetch behavior work best over HTTP(S), use a local web server rather than opening `index.html` directly.

For example, with Python:

```bash
python3 -m http.server 8080
```

Then visit:

`http://localhost:8080`

Note: the sample frontend expects `/api/proxy` on the same origin. For a complete local setup, reverse-proxy `/api/proxy` to your Worker or run the Worker locally with Wrangler.

## Important limitations

This starter intentionally does not include:
- network-filter evasion
- tab cloaking
- fake Google/Google Docs identity
- unrestricted arbitrary-domain proxying
- credential interception
- bypasses for school/workplace controls

It is intended for authorised educational or development environments.
