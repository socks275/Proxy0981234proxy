/**
 * Nova Educational Gateway — Cloudflare Worker
 *
 * IMPORTANT:
 * This is intentionally an allowlist proxy. Add only domains you own,
 * operate, or have explicit permission to access through this gateway.
 */
const ALLOWED_HOSTS = new Set([
  "example.com",
  "www.example.com"
]);

function corsHeaders(){
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}

export default {
  async fetch(request) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS")
      return new Response(null, {headers:corsHeaders()});

    if (url.pathname === "/") {
      return new Response("Nova Educational Gateway", {
        headers: {"content-type":"text/plain;charset=UTF-8"}
      });
    }

    if (url.pathname !== "/api/proxy")
      return new Response("Not found", {status:404});

    const target = url.searchParams.get("url");
    if (!target)
      return new Response("Missing url", {status:400, headers:corsHeaders()});

    let targetURL;
    try { targetURL = new URL(target); }
    catch { return new Response("Invalid URL", {status:400,headers:corsHeaders()}); }

    if (!["http:","https:"].includes(targetURL.protocol))
      return new Response("Only HTTP(S) URLs are allowed", {status:400,headers:corsHeaders()});

    if (!ALLOWED_HOSTS.has(targetURL.hostname))
      return new Response("Domain is not on the educational allowlist.", {status:403,headers:corsHeaders()});

    // Prevent credentials and unusual ports from being forwarded.
    if (targetURL.username || targetURL.password || (targetURL.port && !["80","443"].includes(targetURL.port)))
      return new Response("URL configuration is not permitted.", {status:403,headers:corsHeaders()});

    const upstream = new Request(targetURL.href, {
      method:"GET",
      headers:{
        "User-Agent":"Nova-Educational-Gateway/1.0",
        "Accept":"text/html,application/xhtml+xml"
      },
      redirect:"follow"
    });

    const response = await fetch(upstream);
    const headers = new Headers(response.headers);
    for (const [k,v] of Object.entries(corsHeaders())) headers.set(k,v);
    headers.set("X-Content-Type-Options","nosniff");
    headers.set("Cache-Control","no-store");

    return new Response(response.body, {
      status:response.status,
      statusText:response.statusText,
      headers
    });
  }
};
