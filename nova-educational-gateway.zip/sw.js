// Minimal Service Worker for the Nova educational frontend.
// It caches only the local app shell; it does not intercept arbitrary sites.
const CACHE="nova-edu-v1";
const ASSETS=["/","/index.html","/sw.js"];

self.addEventListener("install",event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)));
  self.skipWaiting();
});
self.addEventListener("activate",event=>{
  event.waitUntil(self.clients.claim());
});
self.addEventListener("fetch",event=>{
  const u=new URL(event.request.url);
  if(u.origin===self.location.origin && ASSETS.includes(u.pathname)){
    event.respondWith(caches.match(event.request).then(r=>r||fetch(event.request)));
  }
});
